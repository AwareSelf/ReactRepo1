
import { useState,useEffect } from 'react';

const DisplayEmp1 = () => {

   
    const [emp,setEmp] =  useState(null);
    const [error,setError] =  useState("");
    const [isLoading,setIsLoading] = useState(false);  
    const [formid,setFormid] = useState(1);
    const [formbonus,setFormbonus] = useState(5000);
    const [isSubmitted,setIsSubmitted] =  useState(false);

  //  const [emparr,setEmpArr] = useState([]);

  

    useEffect(()=>{
    async function getEmp(id,bonus)
    {
      try
       {
        setIsLoading(true); 
        setEmp(null);  
        setError("");
        setIsSubmitted(false);
        console.log('abt to call fetch...');
        const p = await fetch("http://localhost:8085/emp-feign/"+id+"/"+bonus);
        if(p.ok)
        {
          const e = await p.json();
          console.log(e);
          setEmp(e);
          console.log('after setemp'+e.empId);
        }
        else throw Error('Emp with id:'+id+' not found, Response Status is:'+p.status);
       
      }
      catch(error)
      {
        console.log(error);
        console.log(error.message);
        setError(error.message);
      }

      setIsLoading(false);
    }
    getEmp(formid,formbonus);

    },[isSubmitted])

   let result;
    if(isLoading)
     result = 'Loading Emp';
    else if(emp!=null)
     result = <p> Emp Details: {'emp id:'+emp.empId+','+
                                'emp name:'+emp.empName+','+
                                'emp salary:'+emp.empSalary+','+
                                'emp yearly bonus:'+emp.empYearlyBonus+','+
                                'emp total annual salary:'+emp.empTotAnnSalary}</p>
    else if(error!='')
     result = <p>{'Error while fetching Emp:'+ error}</p> 



    const handleSubmit = (event)=> {
        event.preventDefault();
        console.log('submit called:emp id ='+formid+', bonus ='+formbonus);
        setFormid(formid);
        setFormbonus(formbonus);
        setIsSubmitted(true);
       
    }  


    return(
        <>
        <div>
          <h3>Please enter following Employee details:</h3>
          <hr/>
           <form onSubmit={handleSubmit}>
             <label>Id</label> <br/>
              <input placeholder='Id'
                   type='text'  
                   name='id' 
                   value={formid}
                   onChange={(event)=>setFormid(event.target.value)}
                  />
               
              <br/>
              <label>Bonus</label> <br/>
              <input placeholder='Yearly Bonus'
                   type='text'  
                   name='bonus' 
                   value={formbonus}
                   onChange={(event)=>setFormbonus(event.target.value)}
                  />
              
              <br/>     
              <input type='submit' />
             </form>
        </div>

        <div>
            { result }
        </div>
        </>
    );

}

export default DisplayEmp1;