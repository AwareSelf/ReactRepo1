import logo from './logo.svg';
import './App.css';
import DisplayEmp from './DisplayEmp';
import DisplayEmp1 from './DisplayEmp1';


function App() {
  return (
    <div className="App">
      <DisplayEmp/>

      {/*
      
      <hr/>
      <DisplayEmp1/> 
     
      */}
    </div>
  );
}

export default App;
