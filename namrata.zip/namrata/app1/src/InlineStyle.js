
function InlineStyle()
{

    return(
        <h5 style={{textAlign: "center"}}>
        Note:<br/>
        To give inline style to components, use double curly braces.<br/>
        first curly braces is for JSX.<br/>
        sec curly brace is to give CSS.<br/>
        also <br/>
        css-property-name should be camelCase when used inside .js file.<br/>
        </h5>
    );
}

export default InlineStyle;