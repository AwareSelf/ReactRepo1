
let arr = ['a','b','c'];

 let ele = arr.find(e=>e=='b');
 console.log(ele);

 let loc = arr.findIndex(e=>e=='b');
 console.log('loc of element "b" is:'+loc);

 //emp1 is object literal
 //object literal can be created without class
 let emp1 = {empid:1,empname:'ram',empsal:2000};
 console.log(emp1);
 console.log(emp1.empid);
 console.log(emp1.empname);
 console.log(emp1.empsal);

 let emparr =[{empid:1,empname:'ram',empsal:2000},
              {empid:2,empname:'shyam',empsal:5000},
              {empid:3,empname:'aman',empsal:6000}];
console.log(emparr);
console.log(emparr[0]);
console.log(emparr[0].empname);

