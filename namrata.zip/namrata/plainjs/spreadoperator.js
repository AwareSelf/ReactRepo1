
//pass by ref - if you assign same reference
// assigning same ref shares same object and does nt create copy
let arr = [1,4,5];
console.log(arr);
let arr1 = arr;
arr1[1] = 14;

console.log(arr);

let e1 = {id:1,name:'ram'};
let e2=e1;
e2.name = 'shyam';
console.log(e1);


function passbyref()
{
    let arr = [1,4,5];
    console.log(arr);
    return arr;
}

let arrx = passbyref();
console.log(arrx);

//use spread operator to create a copy of object
//array and function is also treated as object in JS
console.log('cloning/creating copy using spread operator...');
let arr3 = [2,4,5];

let arr4 = [...arr3];

console.log(arr4);

arr4[1] = 14;
console.log(arr4);
console.log(arr3);

let arr5 = [...arr3,12];
console.log("arr5:"+arr5);//creating a copy & adding extra value

let e3 = {id:1,name:'ram'};
let e4 = {...e3};
console.log(e4); //exact clone/copy
let e5 = {...e3,sal:2000};
console.log(e5); //creating a clone as well as adding extra property




