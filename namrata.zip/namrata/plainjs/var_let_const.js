console.log(x);
var x=5;
console.log(x);

//let
/*
console.log(x);
let x=5;
console.log(x);
*/
/*
var has function scope, so if u redefine same var in function 
it will pickup last assigned value 
in below func, variable a has same memory allocated at start
as var has function scope
*/
function f1()
{
  var a=10;
  console.log(a);
  {
    var a=20;
    console.log(a);
  }
  console.log(a);

}
f1();
/*
let has block scoped so it will print a value assigned in 
the same scope
in below func, variable 'a' has diff memories allocated
for eachh scope
*/
function f2()
{
  let a=10;
  console.log(a);
  {
    let a=20;
    console.log(a);
  }
  console.log(a);

}
f2();


//let vs const

let no=4;
no=no+1;

const no1=5;
//no1=no1+1;   //const variable cannot be changed