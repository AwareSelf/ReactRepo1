class Emp {
    
    constructor(empid,empname,empsal) {
      this.empid=empid;
      this.empname=empname;
      this.empsal=empsal;
    }
  
    showEmp() {
      console.log("empid:"+this.empid+
                  "empname:"+this.empname+
                  "empsalary:"+this.empsal);

      console.log(`emp id: ${this.empid}
                   emp name: ${this.empname}
                   emp sal : ${this.empsal}`);
    }

    getempid()
    {
        return this.empid;
    }
  }
  
  const emp1 = new Emp(1,"Ram",2000);
  emp1.showEmp();
  emp1.getempid();
  const emp2 = new Emp(2,"Shyam",3000);
  emp2.showEmp();
  emp2.getempid();
  
 console.log(emp2.empsal);
 emparr = [emp1,emp2];
 emparr.forEach(e=>console.log(e.empname));
 emparr.forEach(e=>{
                  let annsal = e.empsal*12;
                  console.log('annsal of emp:'+e.empname+'is'+annsal);
                });