
const arr = [1,3,4,6];

console.log('standard for loop using index');
for(let i=0;i<arr.length;i++)
{
    console.log(arr[i]);
}

console.log('foreach loop');
arr.forEach(e=>console.log(e));

console.log('enhanced for loop java == for-of loop');
for(let e of arr)
{
    console.log(e);
}

let e = {empid:1,empname:'Ram',empsal:2000};
for(let p in e)
{
    console.log(p);
    console.log(e[p]);
}