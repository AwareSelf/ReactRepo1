import { useState, useEffect, useCallback} from 'react'
import React from 'react';
import AddMovie from './AddMovie';

//import axios from 'axios'
import MovieList from './MovieList';

// continues below (1)

import './App.css';

function App() {

  // continues from above (1)

  const [movies, setMovies] = useState([]);
  const [error, setError] = useState(null);
  const [isLoading,setLoading] = useState(false);

  /* useCallback() hook ensures that fetchMovieHandler2 function is not 
  recreated unnecessarily everytime App component re-renders */
   const fetchMoviesHandler2 = useCallback(async ()=>
  {
    try
    {
    setLoading(true);
    setError(null);
  //  const response = await fetch("https://swapi.dev/api/films")
  const response = await fetch('https://react-http-4ce32-default-rtdb.firebaseio.com/movies.json');

    if (response.status === 404) {
      throw new Error('Page not found');
    } else if (response.status === 500) {
      throw new Error('Server error');
    } else if (!response.ok) {
      throw new Error(`something went wrong.. HTTP error! status: ${response.status}`);
    }
     
    const data = await response.json();

    const loadedMovies = [];

        for(const key in data)
        {
          loadedMovies.push({
            id:key,
            title: data[key].title,
            openingText: data[key].openingText,
            releaseDate: data[key].releaseDate,
          });
        }

        setMovies(loadedMovies);
       /*
        console.log(data.results);
        const transformedMovies = data.results.map(movieData =>
          {
            return {
             id:movieData.episode_id,
             title:movieData.title,
             openingText:movieData.opening_crawl,
             releaseDate:movieData.release_date
            };
          });
          setMovies(transformedMovies);
          */
    }
    catch(error)
    {
     // console.log('inside catch:'+error.message);
      setError(error.message);
    }
    setLoading(false);
  },[]); 

 /*
   useEffect ensures that fetchMoviesHandler2() will be called first time
   when application renders and after that whenever fetchMovieHandler2() is recreated.

   since fetechMovieHandler2() is passed to callback it will not be recreated and
   hence changed everytime App component rerenders.

 */
  useEffect(()=>{
    fetchMoviesHandler2();
  },[fetchMoviesHandler2]);

  async function addMovieHandler(movie) {
    console.log(movie);
    const response = await fetch('https://react-http-4ce32-default-rtdb.firebaseio.com/movies.json',{
      method : 'POST',
      body : JSON.stringify(movie),
      headers : {
        'Content-Type' : 'application/json'
      }
     });
     const data = await response.json();
     console.log(data);
  }

  let content = <p>No Movies Found</p>;
  if(movies.length>0)
  {
    content = <MovieList movies={movies} />;
  }
  if(error)
  {
    content = <p>{error}</p>;
  }
  if(isLoading)
  {
    content = <p>loading...</p>;
  }



  return (
    <React.Fragment>
      <section>
        <AddMovie onAddMovie={addMovieHandler} />
      </section>
      <section>
        {/*  
            <button onClick = { fetchMoviesHandler0}>FetchMovies</button> 
            <button onClick = { fetchMoviesHandler1}>FetchMovies</button> */}
            <button onClick = { fetchMoviesHandler2}>FetchMovies</button>
    
      </section> 
     <section>
        {content}
      </section>
    </React.Fragment>
  );
}

export default App;

//https://github.com/academind/react-complete-guide-code/tree/03-react-basics-working-with-components/code