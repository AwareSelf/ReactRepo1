import { useState, useEffect} from 'react'
import React from 'react';

//import axios from 'axios'
import MovieList from './MovieList';

// continues below (1)

import './App.css';

function App() {

  // continues from above (1)

  const [movies, setMovies] = useState([]);
  const [error, setError] = useState(null);
  const [isLoading,setLoading] = useState(false);

  //this function is without error handling
  function fetchMoviesHandler0()
  {
    setLoading(true);
    setError(null);
    
    fetch("https://swapi.dev/api/films")
    .then(response => {
      console.log(response);
      setError(null);
      return response.json();
      })
     .then((data) =>
     {
        
      console.log(data.results);
      const transformedMovies = data.results.map(movieData =>
        {
          return {
           id:movieData.episode_id,
           title:movieData.title,
           openingText:movieData.opening_crawl,
           releaseDate:movieData.release_date
          };
        });
        setMovies(transformedMovies);
        
      })
  
       setLoading(false);

  }

  function fetchMoviesHandler1()
  {
    setLoading(true);
    setError(null);
    
    fetch("https://swapi.dev/api/films")
    .then(response => {
      console.log(response);
      setError(null);
      if(response.ok)
        response.json().then((data) =>
        {
           
         console.log(data.results);
         const transformedMovies = data.results.map(movieData =>
           {
             return {
              id:movieData.episode_id,
              title:movieData.title,
              openingText:movieData.opening_crawl,
              releaseDate:movieData.release_date
             };
           });
           setMovies(transformedMovies);
           
         })
      else throw Error('something went wrong.. response status is :'+response.status);
    })
    .catch(error => { setError(error.message); });
        
        setLoading(false);

  }

  async function fetchMoviesHandler2()
  {
    try
    {
    setLoading(true);
    setError(null);
    const response = await fetch("https://swapi.dev/api/films")
    if(!response.ok)
    {
      //console.log(response);
      throw new Error('something went wrong.. response status is '+response.status);
    }
   
    const data = await response.json();

   
        console.log(data.results);
        const transformedMovies = data.results.map(movieData =>
          {
            return {
             id:movieData.episode_id,
             title:movieData.title,
             openingText:movieData.opening_crawl,
             releaseDate:movieData.release_date
            };
          });
          setMovies(transformedMovies);
    }
    catch(error)
    {
     // console.log('inside catch:'+error.message);
      setError(error.message);
    }
    setLoading(false);
  } 

  let content = <p>No Movies Found</p>;
  if(movies.length>0)
  {
    content = <MovieList movies={movies} />;
  }
  if(error)
  {
    content = <p>{error}</p>;
  }
  if(isLoading)
  {
    content = <p>loading...</p>;
  }



  return (
    <React.Fragment>
     <section>
   {/*  
      <button onClick = { fetchMoviesHandler0}>FetchMovies</button> 
      <button onClick = { fetchMoviesHandler1}>FetchMovies</button> */}
      <button onClick = { fetchMoviesHandler2}>FetchMovies</button>
      </section> 
   
    <section>
     {content}
    </section>
    </React.Fragment>
  );
}

export default App;

//https://github.com/academind/react-complete-guide-code/tree/03-react-basics-working-with-components/code