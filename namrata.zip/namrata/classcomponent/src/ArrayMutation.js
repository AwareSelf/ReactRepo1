import { useState } from "react";
function ArrayMutation()
{
  const [arr,setArr] = useState([1,2,3,4]);

  
//setting entire new local array to set state is working...
  const addarray = ()=>{
    let arr1 = [2,3,5,7];
    setArr(arr1);

  }

  const addele = (no)=>{
    /*
    below commented code does not trigger re-render, although console.log(arr) shows newly added value 6 
    that means arr is modified,but it doesnt trigger re-render on UI.
    Reason: arr1 is same object as arr, so you are mutating the original object added to state and not 
    setting new local arr object to state (as in addarray method above) */
    /*
    console.log(no);
    let arr1 = arr;
    console.log(arr1);
    arr1.push(no);    //..this push will not work as arr1 is same as arr (set inside the state)
    console.log(arr1);
    setArr(arr1); //although var arr1 is diff, its still the same original arr set in state
    console.log(arr);
    */
    console.log('using correct way..');
    console.log(no);
    let arr1 = [...arr];
    console.log(arr1);
    arr1.push(no); //this push will work when u set arr1 in setstate as arr1 object is not same as arr
    console.log(arr1);
    setArr(arr1);
   }
  return(
   
   <>
    <ul>
        {arr.map(no=><li key={no.toString()}>{no}</li>)}
    </ul> 
    <button onClick={addarray}>Change Array</button>
    <button onClick={()=>addele(6)}>Add new Element</button>
   </>

  );

}

export default ArrayMutation;