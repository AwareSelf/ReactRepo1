import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  //remove strict-mode to see lifecycle methods being called correctly
  //using strict-mode component mounts-unmounts-remounts (behaviour added in strict mode)
  //https://react.dev/blog/2022/03/29/react-v18#new-strict-mode-behaviors

  //<React.StrictMode>
    <App />
  //</React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
