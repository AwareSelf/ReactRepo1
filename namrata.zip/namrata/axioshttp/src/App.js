import logo from './logo.svg';
import './App.css';
import EmpCrudHttp from './EmpCrudHttp';

function App() {
  return (
    <div className="App">
      <header className="App-header">
      <EmpCrudHttp />
      </header>
    </div>
  );
}

export default App;
