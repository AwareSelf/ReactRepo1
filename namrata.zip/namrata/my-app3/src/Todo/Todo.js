
import React from 'react';
import { useReducer,useState } from "react";
import TodoService from './TodoService';

const initialTodos = [
    {
      id: 1,
      title: "Todo 1",
      complete: false,
    },
    {
      id: 2,
      title: "Todo 2",
      complete: false,
    },
  ];

function Todo (props)
{
  
  
  const [id, setId] = useState(3);
  const [title, setTitle] = useState("watch movie");
  const [complete, setComplete] = useState(true);
  const [todos, dispatch] = useReducer(TodoService, initialTodos);

     const lstTodos = todos.map(
      (todo) =>
         <li key={todo.title.toString()}>
              {todo.id} &nbsp;
              {todo.title} &nbsp;
              {todo.complete? 'true':'false'} &nbsp;
              <input type="button" 
                      onClick={(e)=>handleDelete(e,todo.id)} 
                      value='delete' />
         </li>  
         
      );

   const handleDelete = (event ,id)  =>
   {
     event.preventDefault();
     console.log('about to delete todo with id '+id);
     dispatch({
      type:'delete',
      id:id,
       });

   }
   const handleSubmit = (event) =>
    {
      event.preventDefault();
      dispatch({
                type:'added',
                id:id,
                title:title,
                complete:complete });

    
    };

    const handleChangeId = (event) =>
    {
      setId(event.target.value)
    };

    const handleChangeTitle = (event) =>
    {
      setTitle(event.target.value);
    }
    const handleChangeComplete = (event) =>
    {
      setComplete(event.target.checked);
      
    }
    
  
      return(
        <div>
      <form onSubmit={(e)=>handleSubmit(e)}>
        <label>
          id:
          <input type="text" 
                 name="id" 
                 value={id} 
                 onChange={(e)=>handleChangeId(e)} />
        </label>
        <label>
          Title:
          <input type="text"  
                 name="title" value={title} 
                 onChange={(e)=>handleChangeTitle(e)} />
        </label>
        <label>
          Completed:
          <input type="checkbox"
                 value="complete"
                 onChange={(e)=>handleChangeComplete(e)} />
        </label>
        <input type="submit" value="Submit" />
      </form>
      <hr/>
       
      <ul>{lstTodos}</ul>
      </div>

      );
    
}

export default Todo;