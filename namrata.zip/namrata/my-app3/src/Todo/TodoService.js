

const TodoService = (todos,action) =>  {

    switch(action.type)
    {
        case 'added': {
           console.log(action);
            return [
                ...todos,
                {
                  id: action.id,
                  title: action.title,
                  complete: action.complete,
                },
              ];
        }

        case 'delete' : {
          console.log(action);
          return todos.filter((todo) => todo.id !== action.id);
        }

        default:
            {
                throw Error('Unknown action: ' + action.type);
              }

    }
}

export default TodoService;