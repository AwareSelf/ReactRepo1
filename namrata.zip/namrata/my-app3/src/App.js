import './App.css';
import Todo from './Todo/Todo'

function App() {
  return (
    <div className="App">
     <Todo />
    </div>
  );
}

export default App;
