
function Welcome(props)
{
    return(
        <h1>Hello, namrata</h1>
    );
}

export default Welcome;