import React from 'react';
/*
function Clock(props) {
    return (
      <div>
        <h1>Hello, world!</h1>
        <h2>It is {props.date.toLocaleTimeString()}.</h2>
      </div>
    );
  }
  //converting Clock component function to ES6 component class
  class Clock extends React.Component
  {
    render() {
        return (
            <div>
                 <h1>Hello, world!</h1>
                 <h2>It is {this.props.date.toLocaleTimeString()}</h2>
            </div>
        );
     }
  }
  */

  class Clock extends React.Component
  {

    constructor(props)
    {
        super(props);

        //set initial state
        this.state = { date:new Date() };  //initial state

    }

    //lifecycle method
    /*
    We can declare special methods on the component class to run some code when a 
    component mounts and unmounts:
    */
    
    /* The componentDidMount() method runs after the component output has been rendered 
      to the DOM. This is a good place to set up a timer: */
    componentDidMount() {

        this.timerId = setInterval(
                            () => { 
                                this.tick()
                                },
                            1000
                        );
    }
  
    /*
    clear that timer whenever the DOM produced by the Clock is removed. 
    This is called “unmounting” in React.
    */
    componentWillUnmount() {

        clearInterval(this.timerId);
    }

    //use this.setState() to schedule updates to the component's local state:
    tick()
    {
        this.setState(
            {date:new Date()}
        );
    }

    render() {
        return (
            <div>
                 <h1>Hello, world!</h1>
                 <h2>zone is {this.props.timezone}.</h2>
                 <h2>It is {this.state.date.toLocaleTimeString()}</h2>

            </div>

        );
     }
  }

  export default Clock;