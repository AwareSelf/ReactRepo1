import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import Welcome from './welcome';
import reportWebVitals from './reportWebVitals';

const root = ReactDOM.createRoot(document.getElementById('root'));
/*
Let’s recap what happens in this example:

1) We call root.render() with the <Welcome name="Namrata" /> element.
2) React calls the Welcome component with {name: 'Namrata'} as the props.
3) Our Welcome component returns a <h1>Hello, Namrata</h1> element as the result.
4) React DOM efficiently updates the DOM to match <h1>Hello, Namrata</h1>

const element = <Welcome name="Namrata" />
root.render(element);
*/

root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);





/*
const element = <h1>Hello, world</h1>;
root.render(element);
*/
/*
Updating the Rendered Element
React elements are immutable. Once you create an element, you can’t change its children or attributes. An element is like a single frame in a movie: it represents the UI at a certain point in time.

With our knowledge so far, the only way to update the UI is to create a new element, and pass it to root.render().

Consider this ticking clock example:
*/

function tick() {
  const element = (
    <div>
      <h1>Hello, world!</h1>
      <h2>It is {new Date().toLocaleTimeString()}.</h2>
    </div>
  );
  root.render(element);
}
//setInterval(tick, 1000);
//It calls root.render() every second from a setInterval() callback.

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
