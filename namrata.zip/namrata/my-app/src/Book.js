

//Book is parent component that contains nested child components BookDet and AuthorDet.
/*
To use it in app component, declare and define below in App.js:-
const bk = { bookname:'abc' , 
  bookdesc:'this is book abc',
  bookdate:'3/1/2023',
  noofcopies:10
};

const au = { authname:'namrata',
       authaddr:'j504,AWHO,Nerul'
      };

inside App component function:-
function App {
    return(
      <Book bk={bk} auth={au} infodt="3/1/2023" />
    );
}
export default App;
*/

//Book component function
/*
Note:Props are Read-Only.Whether you declare a component as a function or a class, 
it must never modify its own props.
*/
function Book(props) {
    return (
      <div className="Bookinfo">
        <BookDet book={props.bk} />
        <AuthorDet author={props.auth} />   
        <div>
            {props.infodt}
        </div>
       </div>
    );
  }

  //BookDet Component function
  function BookDet(props)
  {
  return (
    <div className="BookDet">
        <div className="BookName">
            {props.book.bookname}
        </div>
        <div className="BookInfo">
          {props.book.bookdesc}
        </div>
       
        <div className="bookStock">
            {props.book.noofcopies}
        </div>
     </div>
    );
  }

  //AuthorDet component function
  function AuthorDet(props)
  {
     return(
       <div className="AuthorDetails"> 
        <div>
            {props.author.authname}
        </div>
        <div>
            {props.author.authaddr}
        </div>
       </div>
     );
  }
  


  export default Book;