import './App.css';
import Welcome from './welcome';
import Book from './Book';
import Clock from './Clock';
import Form from './Form';


function formatName(user) {
  return user.firstName + ' ' + user.lastName;
}

const user = {
  firstName: 'Harper',
  lastName: 'Perez'
};

var url = "https://www.reactjs.org";
const element = (
  <h1>
    Hello, {formatName(user)}!
  </h1>
);

function getGreeting(user) {
  if (user) {
    return <h1>Hi, {formatName(user)}!</h1>;
  }
  return <h1>Hi, Stranger.</h1>;
}
//You may use quotes to specify string literals as attributes:
const element1 = <a href="https://www.reactjs.org"> link </a>;

//You may also use curly braces to embed a JavaScript expression in an attribute:
const element2 = <a href={url}> link </a>;

/*
Don’t put quotes around curly braces when embedding a JavaScript expression in an attribute. 
You should either use quotes (for string values) or curly braces (for expressions), but not 
both in the same attribute.
*/


const bk = { bookname:'abc' , 
  bookdesc:'this is book abc',
  bookdate:'3/1/2023',
  noofcopies:10
};

const au = { authname:'namrata',
       authaddr:'j504,AWHO,Nerul'
      };

//root App component has nested  Welcome component and Book Component
function App() {
  return (
    <div className="App">
       <p>We are going to learn React!</p>
       {element}
       {getGreeting()}
       {getGreeting(user)}
       {element1} <br></br>
       {element2}

       <h3>Composing child components inside parent component. </h3>
       <div>
         <Welcome name="Harvey" />
         <Welcome name="Jessica" />
         <Book bk={bk} auth={au} infodt="3/1/2023" />
         <Clock timezone="IST"/>
         <hr></hr>
         <Form/>
       </div>
    </div>
  );
}

export default App;
