/*
function Form() {
    function handleSubmit(e) {
    // you cannot return false to prevent default behavior in React. 
    // You must call preventDefault explicitly.
      e.preventDefault();
      console.log('You clicked submit.');
    }

    function handleClick(e) {
        alert('you clicked button '+e.target.value);
        console.log(e.target.value);
        console.log(e);
    }

  
    return (
      <form onSubmit={handleSubmit}>
        <input type='text' name='name' /> <br></br>
        <input type="button" onClick={handleClick} name='Greet' value='greet'></input> <br></br>
        <button type="submit">Submit</button>
      </form>
    );
  }
  */

import React from "react";

  class Form extends React.Component
  {
    constructor(props)
    {
        super(props);
        this.state = {isToggleOn: true};

        // This binding is necessary to make `this` work in the callback handleClick1
        this.handleClick1 = this.handleClick1.bind(this);
    }
    handleSubmit(e) {
     // you cannot return false to prevent default behavior in React. 
     // You must call preventDefault explicitly.
      e.preventDefault();
      console.log('You clicked submit.');
      console.log(e);
      alert('text field value is '+e.target.elements.name.value);
    }
    
    handleClick(e,val) {
        alert('you clicked button '+e.target.value);
        console.log(e.target.value);
        console.log(e);
        alert('passed val is '+val);
        alert('text field value is '+e.target.form.elements.name.value);
      // console.log(e.target.elements);
    }

    //to make 'this' ref available inside callback function you need to bind it to callback func 
    //in constructor
    handleClick1() {
        this.setState(prevState => ({
          isToggleOn: !prevState.isToggleOn
        }));
      }

    chngInputValue(evt)
    {
        alert(evt.target.value);
    }  

    render(){
        return(
         <form onSubmit={this.handleSubmit} name="f">
            <input type='text' name='name' 
          //  onChange={evt => this.chngInputValue(evt)}
          />
           <br></br>
           
            <input type="button" 
                   onClick={(e)=>this.handleClick(e,'aaa')} 
                   name='Greet' 
                   value='greet'>
            </input> <br></br>
           
            <button type="submit">Submit</button> <br></br>
           
            <button  type="button" onClick={this.handleClick1}>
                 {this.state.isToggleOn ? 'ON' : 'OFF'}
             </button>
          </form>

        );
    }
  }

  export default Form;