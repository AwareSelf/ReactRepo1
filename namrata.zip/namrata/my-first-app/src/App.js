import logo from './logo.svg';
import './App.css';
import Welcome from './Welcome';
import Comment from './Comment';
import Clock from './Clock';

const comment = {
  date: new Date(),
  text: 'I hope you enjoy learning React!',
  author: {
    name: 'Hello Kitty',
    avatarUrl: 'http://placekitten.com/g/64/64'
  }
};
//composing Welcome component inside App Component
function App() {
  return (
    <div className="App">
     <Welcome name="Namrata" />
     <Welcome name="Rahul" />
     <hr/>
     <Comment
        date={comment.date}
        text={comment.text}
        author={comment.author} />
      <hr/>
      <Clock />  
    </div>
  );
}

export default App;
