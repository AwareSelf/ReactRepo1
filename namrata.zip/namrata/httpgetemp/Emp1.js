import {useState,useEffect,useCallback} from 'react';
import axios from 'axios';

function Emp1() {
    const [error,setError] = useState(null);
    const [error1,setError1] = useState(null);
    const [isLoading,setIsLoading] =  useState(false);
    const [isLoading1,setIsLoading1] =  useState(false);
    const [emp,setEmp] = useState(null);
    const [postedEmp,setPostedEmp]=useState(null);


    const client = axios.create({
        baseURL:"http://localhost:8085/emp"
    });

const getemp = async (id) =>
{
    try
    {
        setError(null);
        setIsLoading1(true);
    const response = await client.get("/"+id);
           console.log(response.data);
     if (response.status === 404) {
         throw new Error('Emp with Id='+id+' Not Found'+response.statusText);
     } else if (response.status === 500) {
         throw new Error('Server error');
     } else if (response.status!=200) { 
         throw new Error(`get emp failed.. HTTP error! status: ${response.status}`);
     }
     setIsLoading1(false);
     
     const emp = response.data;
     console.log(emp.empId);
     console.log(emp.empName);
     setEmp(emp);
    
    }
    catch(error)
    {
       console.log(error.response.data.message);
        console.log('inside catch, fetch failed:'+error.message);
        setError(error.response.data.message);
        setIsLoading1(false);
     
    }
}


const addemphandler = async (id,name,sal)=>{
  
    setIsLoading(true);
    try
    {
          const response = await client.post('',{
            empId: id,
            empName: name,
            empSalary: sal 
            });

            if(response.status!=201)
            {
              setIsLoading(false);
              throw new Error('post emp failed: response status:'+response.status+':'+response.statusText);
            } 
            
          const data =  response.data;
            setPostedEmp(data);
            setIsLoading(false);
         
      
    }
    catch(error)
    {
        setError1(error);
    }
}
 


let getcontent ='';
    if(isLoading1)
    {
      getcontent = 'Loading..';
     
    }
    else if(emp)
    {
        getcontent = emp.empId+', '+emp.empName;
    }
    else if(error)
    {
      //  console.log(error);
        getcontent = error;
      
    }
   

 let postcontent='';
if(postedEmp)
{
    postcontent = 'Emp with Id :'+postedEmp.empId+" posted successfully";
}
if(error1)
{
    postcontent = error1;
}


    return(
        <div>
            <section>
                <button onClick={ ()=>{ addemphandler(22,'ramya',5000); } }>Add Emp</button> 
                <br></br>
                <p>{postcontent}</p>
            </section>
            <section>
                <button onClick={ ()=>{ getemp(22);} }>Get Emp</button>
           
            </section>
            <section> 
              <p>{getcontent}</p>
            </section>
        </div>
    );
    
}

export default Emp1;

//https://blog.logrocket.com/how-to-make-http-requests-like-a-pro-with-axios/