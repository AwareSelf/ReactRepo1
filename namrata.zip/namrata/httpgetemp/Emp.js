import {useState,useEffect,useCallback} from 'react';

function Emp() {
    const [error,setError] = useState(null);
    const [error1,setError1] = useState(null);
    const [isLoading,setIsLoading] =  useState(false);
    const [emp,setEmp] = useState(null);
    const [empname,setEmpname]=useState(null);

    
const getemp = async (id) =>
{
    try
    {
        setError(null);
        setIsLoading(true);
    const response = await fetch("http://localhost:8085/emp/"+id);
  
        console.log(response);
     if (response.status === 404) {
         throw new Error('Emp with Id='+id+' Not Found');
     } else if (response.status === 500) {
         throw new Error('Server error');
     } else if (!response.ok) { 
         throw new Error(`get emp failed.. HTTP error! status: ${response.status}`);
     }
     setIsLoading(false);
     
     const emp = await response.json();
     console.log(emp.empId);
     console.log(emp.empName);
     setEmp(emp);
    
    }
    catch(error)
    {
        console.log('inside catch, fetch failed:'+error.message);
        setError(error.message);
        setIsLoading(false);
     
    }
}


const addemphandler = async (id,name,sal)=>{
    const emp = {
        empId: id,
        empName: name,
        empSalary: sal 
        };
      
    setEmp(emp);
    setIsLoading(true);
    try
    {
       
    const response = await fetch("http://localhost:8085/emp",{
        method:'post',
        headers : {
            'Content-Type' : 'application/json'
        },
        body: JSON.stringify(emp)
      });
      if(!response.ok)
      {
        setIsLoading(false);
        throw new Error('post emp failed: response status:'+response.status);
      }
      console.log('no error'+response);
      const empname = await response.text();
      setEmpname(empname);
      setIsLoading(false);
    }
    catch(error)
    {
        setError1(error);
    }
}
 
/*
useEffect(()=>{
    getemp();
    addemphandler();
},[getemp ,addemphandler ])
*/
let getcontent ='';
    if(isLoading)
    {
      getcontent = 'Loading..';
     
    }
    else if(emp)
    {
        getcontent = emp.empId+', '+emp.empName;
    }
    else if(error)
    {
      //  console.log(error);
        getcontent = error;
      
    }
   

 let postcontent='';
if(empname)
{
    postcontent = 'Emp with empname:'+empname+" posted successfully";
}
if(error1)
{
    postcontent = error1;
}


    return(
        <div>
            <section>
                <button onClick={ ()=>{ addemphandler(22,'ramya',5000); } }>Add Emp</button> 
                <br></br>
                <p>{postcontent}</p>
            </section>
            <section>
                <button onClick={ ()=>{ getemp(22);} }>Get Emp</button>
           
            </section>
            <section> 
              <p>{getcontent}</p>
            </section>
        </div>
    );
    
}

export default Emp;