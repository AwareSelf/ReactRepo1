//https://jsonplaceholder.typicode.com/posts
import Posts from './Posts';

function App() {
  return (
    <div>
     <Posts />
    </div>
  );
}

export default App;
