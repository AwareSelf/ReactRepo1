import axios from 'axios';
import {useState,useEffect} from 'react';

function Posts()
{
    const [posts,setPosts] = useState([]);
    const [title,setTitle] = useState('');
    const [body,setBody] = useState('');

    const client = axios.create({
        baseURL:"https://jsonplaceholder.typicode.com/posts"
    });

    //GET with axios
    useEffect(()=>{

        const fetchpost = async ()=>{

            let response = await client.get('?_limit=10');
            setPosts(response.data);

        };
        fetchpost();

    },[])

    //DELETE with axios
    const deletePosts = async (id)=>{
        try
        {
        await client.delete(`{id}`);

        setPosts(
        posts.filter(post=>{
          return post.id!=id;
        })
        );
       }
       catch(error)
       {
        console.log(error);
       }
     
    }

    const handleSubmit =  (event)=>{

        event.preventDefault();
        addPost(title,body);
    }

    const addPost = async (title,body)=>{

       let response = await client.post('',{
        title:title,
        body:body
       });

       setPosts([response.data,...posts]);
       setTitle('');
       setBody('');

    }


        


    return(
        <div className='app'>
          <nav>
            <h1>POSTS APP!</h1>
          </nav>
           <div className='add-posts-container'>
            <p>All posts!</p>
            {
                 posts.map((post) => {

                 return(
                 <div className='post-card' key={post.id}>
                    <h2 className='post-title'>{post.title}</h2>
                    <p className='post-body'> {post.body} </p>
                    <div className='button'>
                       <div className='delete-btn' onClick={()=>deletePosts(post.id)}>Delete</div>
                    </div>
                 </div>);
                
               })
           }
           </div>
           <div className='posts-container'>
            <form onSubmit={handleSubmit}>
                <label>
                 Title:   <br></br>
                <input type='text' className='form-control' value={title} 
                onChange={(event)=>setTitle(event.target.value)}/>
                </label>
                <label>
                 Body:
                <textarea className='form-control' cols='20' rows='8'
                value={body} onChange={(event)=>setBody(event.target.value)}/>
                </label>
                <input type='submit'/>
           </form>
           </div>
        </div>
        );
}

export default Posts;



       