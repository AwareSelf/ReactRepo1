import React from 'react';

class MailBox extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state = { unreadmessages : props.unreadmessages}; //get initial value from props
    }
    clearAllMessages()
    {
       //can't change props as its readonly but can change state 
       this.setState({ unreadmessages:[] }); 
    }

    render() {
    return (
     <div>
       <h1>Hello</h1>
       { this.state.unreadmessages.length > 0   &&
         <div>
             <h3>you have {this.state.unreadmessages.length} unread messages in ur mailbox!</h3> 
             <button onClick={()=>this.clearAllMessages()}>ClearAllMessages</button>
          </div> 
       }
       
      </div>
    );
    }

}

export default MailBox;