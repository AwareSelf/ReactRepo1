import './App.css';
import Greeting from './Greeting';
import LoginControl from './LoginControl';
import LoginControl1 from './LoginControl';
import Page from './Page';
import MailBox from './MailBox';
import BasicList from './BasicList';
//import NumberList from './BasicList';
import Blog from './ObjectList';
import NumberList1 from './BasicList';
import NameForm  from './formcomponents/NameForm';
import EssayForm from './formcomponents/EssayForm';
import FavCarForm from './formcomponents/FavCarForm';
import UncontrolledNameForm from './formcomponents/UncontrolledNameForm';
import FileInput from './formcomponents/FileInput';
import AddNums from './liftstateup/AddNums';
/*
function App() {
  return (
    <div className="App">
       <Greeting isLoggedIn={false}/>
    </div>
  );
}
*/

function App() {
  const messages = ['React', 'Re: React', 'Re:Re: React'];
  const numbers = [10,20,30,40];

  const posts = [
    {id: 1, title: 'Hello World', content: 'Welcome to learning React!'},
    {id: 2, title: 'Installation', content: 'You can install React from npm.'}
  ];

  return (
    <div className="App">
       <LoginControl1 isLoggedIn={false}/>
       <hr/>
       <Page />
       <hr/>
     
       <MailBox unreadmessages={messages} />
       {/*
       <hr/>
       <BasicList list={numbers} />
       <hr/>
       <BasicList list={messages} />
       <hr/>
       <NumberList numbers={numbers} />
       <hr/>
       <Blog posts={posts} />
       
       <hr/>
        <NumberList1 numbers={numbers} />
    */}
       <hr/> 
       <NameForm />
       <hr/>
       <EssayForm />
       <hr/>
       <FavCarForm />
       <hr/>
       <UncontrolledNameForm />
       <hr/>
       <FileInput/>
       <hr/>
       <AddNums num1={10} num2={20} />
    </div>
  );
}
export default App;
