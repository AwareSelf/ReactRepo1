import Greeting from "./Greeting";
import React from 'react';

function LoginButton(props)
{
    return <button onClick={props.onClick}>Login </button>
}
function LogoutButton(props)
{
    return <button onClick={props.onClick}>Logout </button>
}

class LoginControl1 extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state = { isLoggedIn:false};
    }

    handleLogoutClick()
    {
        console.log('logout button clicked');
        this.setState({ isLoggedIn:false});
    }

    handleLoginClick()
    {
         console.log('login button clicked');
         this.setState({ isLoggedIn:true});
    }


    render() {

        const isLoggedIn = this.state.isLoggedIn;
        let element;
        if(isLoggedIn)
        {
         element = <LogoutButton onClick={()=>this.handleLogoutClick()} /> ;
        }
        else
        {
         element = <LoginButton onClick={this.handleLoginClick.bind(this)} />

        }
              
        return(
            /*
         <div>
            <Greeting isLoggedIn={isLoggedIn} />
            {element}  
         </div>  */

        <div>
            {
                isLoggedIn ? <LogoutButton onClick={()=>this.handleLogoutClick()} />
                            : <LoginButton onClick={this.handleLoginClick.bind(this)} />
            }
        </div>
        
        );

       
    }

}
export default LoginControl1;