
import React from 'react';
class BasicList extends React.Component {

   constructor(props)
   {
     super(props)
     this.state =  {list:props.list};
   }
    render() {
    const list = this.state.list;
    const lstItems = list.map(
         (item) =>
            <li key={item.toString()}>
                 {item} 
            </li>  //don't put curly braces around <li>, its single line function
         );

        return (
            <ul>{lstItems}</ul>
            
        );
    }
}


function NumberList(props) {
    const numbers = props.numbers;
    const listItems = numbers.map((number) =>
      <li>{number}</li>
    );
    return (
      <ul>{listItems}</ul>
    );
  }

  function ListItem(props)
  {
     return(
         <li>{props.value}</li>
     );
  }
  function NumberList1(props) {
    const numbers = props.numbers;
    return (
      <ul>
        {numbers.map((number) =>
          <ListItem key={number.toString()}
                    value={number} />
        )}
      </ul>
    );
  }
//  export default BasicList;
    export default NumberList1;