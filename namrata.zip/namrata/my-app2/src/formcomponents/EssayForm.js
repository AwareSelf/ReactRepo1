import React from 'react';

class EssayForm extends React.Component {

    constructor(props)
    {
        super(props);

        this.state = { value: 'Please write an essay about your favorite outdoor trip.' };
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }

    handleSubmit(event)
    {
      alert('An Essay was submitted, '+this.state.value);
      event.preventDefault();
    }

    handleChange(event)
    {
       this.setState({ value : event.target.value });
    }
    render() {

        return(
           <form onSubmit={this.handleSubmit}>
            <label>
             Essay:   
             <br></br>
                <textarea 
                    value={this.state.value} 
                    onChange={this.handleChange} 
                    rows="4" 
                    cols="50">
                </textarea>
            </label> 
            <br></br>
            
            <input type="submit" value="Submit"/>

           </form> 

        );
    }
}

export default EssayForm;