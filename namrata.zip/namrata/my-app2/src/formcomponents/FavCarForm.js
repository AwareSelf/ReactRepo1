import React from 'react';

class FavCarForm extends React.Component {

    constructor(props)
    {
        super(props);

        this.state = { value: 'mercedes' };
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }

    handleSubmit(event)
    {
      alert('your fav car is, '+this.state.value);
      event.preventDefault();
    }

    handleChange(event)
    {
       this.setState({ value : event.target.value });
    }
    render() {

        return(
          <form onSubmit={this.handleSubmit}>
          <label>Choose a car: &nbsp; 
          <select value= {this.state.value} onChange={this.handleChange} name="cars" id="cars">
             <option value="volvo">Volvo</option>
             <option value="saab">Saab</option>
             <option value="mercedes">Mercedes</option>
             <option value="audi">Audi</option>
          </select>
          </label>
          <br/><br/>
          <input type="submit" value="Submit"/>

          </form> 

        );
    }
}
//<select multiple={true} value={['B', 'C']}>

export default FavCarForm;