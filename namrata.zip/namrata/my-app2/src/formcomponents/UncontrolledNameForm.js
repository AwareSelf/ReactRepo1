import React from 'react';

class UncontrolledNameForm extends React.Component {

    constructor(props)
    {
        super(props);

        this.handleSubmit =  this.handleSubmit.bind(this);

        //note: createRef() is function in React library.don't forget to put round-bracs around func-name
        this.input = React.createRef();  

    }

    handleSubmit(event) {
        alert('A name was submitted: ' + this.input.current.value);
        event.preventDefault();
      }


    render() {

        return(
          <form onSubmit={this.handleSubmit} >
            <label>
            Name: &nbsp;
            <input 
              defaultValue='Namrata'
              type='text' 
              ref={this.input} />
            </label> 
            <input type="submit" value="Submit" />
         </form>
        );
    }
}

export default UncontrolledNameForm;