import Greeting from "./Greeting";
import React from 'react';



class LoginControl extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state = { isLoggedIn:false};
    }

    handleLogoutClick()
    {
        console.log('logout button clicked');
        this.setState({ isLoggedIn:false});
    }

    handleLoginClick()
    {
         console.log('login button clicked');
         this.setState({ isLoggedIn:true});
    }


    render() {

        const isLoggedIn = this.state.isLoggedIn;
        let element;
        if(isLoggedIn)
        {
         element = <button onClick={()=>this.handleLogoutClick()}> Logout </button>;
        }
        else
        {
         element = <button onClick={this.handleLoginClick.bind(this)}>Login </button>;

        }
              
        return(
         <div>
            <Greeting isLoggedIn={isLoggedIn} />
            {element}  
         </div>
        
        );
    }

}
export default LoginControl;