
import React from 'react';


function Warning(props)
{
    if(!props.warning)
      return null;

    return <div className='warning'> 
              Warning!
            </div>
}

class Page extends React.Component {

    constructor(props)
    {
        super(props);
        this.state = { isWarning:true};
    }

    toggleWarning()
    {
        this.setState(state=> ({
            isWarning:!state.isWarning
        })
        );
    }
    render() {

        const warning = this.state.isWarning;

         let ele;

         if(warning)
         {
            ele = <button onClick={()=>this.toggleWarning()}>Hide</button>
         }
         else
         {
            ele = <button onClick={()=>this.toggleWarning()}>Show</button>
         }

        return (
          <div>
            <Warning warning={this.state.isWarning} />

             {ele} <br></br>

             <button onClick={()=>this.toggleWarning()}>
                { warning ? 'Hide' : 'Show' }
             </button>
             
           </div>            
        );
  }
}
export default Page;