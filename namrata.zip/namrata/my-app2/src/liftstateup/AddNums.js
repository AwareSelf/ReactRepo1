import React from 'react';

class InputNum extends React.Component {

    constructor(props)
    {
        super(props);
       this.state = {
        num1:props.num1,
        num2:props.num2
       }

       this.handleNum1Change = this.handleNum1Change.bind(this);
       this.handleNum2Change = this.handleNum2Change.bind(this);
       this.handleOnSubmit = this.handleOnSubmit.bind(this);
 

    }

    handleNum1Change(event)
    {
       console.log('inside handle num1 change..'); 
      this.setState({ num1:event.target.value});
    }

    handleNum2Change(event)
    {
        console.log('inside handle num2 change..'); 
        this.setState({ num2:event.target.value});
    }

    handleOnSubmit(event)
    {
        event.preventDefault();
        console.log('inside child handleOnSubmit.form got submitted..');
        console.log('input form num1='+this.state.num1);
        console.log('input form num2:'+this.state.num2);

        /* 
         similar angular output event emitter, emit method.
          'onSubmitEvt' is ouput EventEmitter here
          bind this event to parent callback.. */
        //pass the num1 and num2 values to parent component
        this.props.onSubmitEvt( parseInt(this.state.num1),
                                parseInt(this.state.num2)
                              );
        
    }

    render() {


        return(

            <form onSubmit={this.handleOnSubmit}>
                <label>
                 num1:   
                <input type='text' name='num1' value={this.state.num1} onChange={this.handleNum1Change} />
                </label>
                <label>
                 num2:  
                 <input type='text' name='num2' value={this.state.num2} onChange={this.handleNum2Change} />  
                </label>
               <input type="submit" value="Submit" />
            </form>
        );
    }
}

class SumResult extends React.Component {
    constructor(props)
    {
        super(props);
        
    }

    render() {

      const result = this.props.sum;
        return(
            <div>
                {result}
            </div>
        );
    }
}

class AddNums extends React.Component {

    constructor(props)
    {
        super(props);
        this.state = {sum:0};
        this.handleOnSubmitParent = this.handleOnSubmitParent.bind(this);
    }

    handleOnSubmitParent(value1,value2)
    {
       console.log('Parent callback method:onsubmit called..evt propagated to parent'); 
      this.setState({sum:value1+value2});
     
    }

   

    render()
    {
       return(
         <div>   
         <InputNum  
            num1={this.props.num1}
            num2={this.props.num2}
            onSubmitEvt={this.handleOnSubmitParent}
         />
         <SumResult sum={this.state.sum}/>
         </div>
        );
    }
}

export default AddNums;