class Human {
    species = 'human';
    }

class Person extends Human {
    name = 'Max';
    printMyName = () => {
     console.log(this.name);
     }
 }
    
     const person = new Person();
     person.printMyName();
     console.log(person.species); 